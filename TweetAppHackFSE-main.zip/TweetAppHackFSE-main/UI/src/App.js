import React from 'react';
import AppContainer from './components/AppContainer';

function App() {
  return (
    <AppContainer />
  );
}

export default App;
